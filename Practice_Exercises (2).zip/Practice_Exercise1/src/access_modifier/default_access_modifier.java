package access_modifier;

public class default_access_modifier {
	void message(){
        System.out.println("This is a message");
    }

}
