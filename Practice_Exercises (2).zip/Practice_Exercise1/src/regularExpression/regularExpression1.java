package regularExpression;
import java.util.regex.*; 
public class regularExpression1 {
	

	/*Create a regular expression that accepts alphanumeric characters only.  
	Its length must be six characters long only.*/  
	public static void main(String args[]){  
	System.out.println(Pattern.matches("[a-zA-Z0-9]{6}", "atul2"));//true  
	System.out.println(Pattern.matches("[a-zA-Z0-9]{6}", "vikdrvarun32"));//false (more than 6 char)  
	System.out.println(Pattern.matches("[a-zA-Z0-9]{6}", "hjfhk2"));//true  
	System.out.println(Pattern.matches("[a-zA-Z0-9]{6}", "arun$2"));//false ($ is not matched)  
	}}  

	//[range]{length}

