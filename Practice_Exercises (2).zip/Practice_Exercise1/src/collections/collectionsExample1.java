package collections;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Vector;
public class collectionsExample1 {
public static void main(String[] args) {
	//ArrayList
	ArrayList<String> list =new ArrayList<>();
	list.add("Rameh");
	list.add("sameh");
	list.add("vameh");
	list.add("tameh");
	list.add("null");
	System.out.println("ArrayList Elements:"+list);
	
	//Vector
    Vector<String> vlist =new Vector<>();
	vlist.add("Rameh");
	vlist.add("sameh");
	vlist.add("vameh");
	vlist.add("tameh");
	vlist.add("null");
	System.out.println("Vector Elements:"+ vlist);
	
	//LinkedList
	LinkedList<String> nlist =new LinkedList<>();
	nlist.add("Rameh");
	nlist.add("sameh");
	nlist.add("vameh");
	nlist.add("tameh");
	nlist.add("null");
	System.out.println("LinkedList Elements:"+ nlist);
}
}
