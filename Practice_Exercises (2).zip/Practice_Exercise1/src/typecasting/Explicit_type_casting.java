package typecasting;

import java.util.Scanner;

public class Explicit_type_casting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner (System.in);
		System.out.println("Enter an integer value:");
		int v = s.nextInt();
		char c= (char) v;
		System.out.println("Character value of the given integer:"+c);
	}

}
