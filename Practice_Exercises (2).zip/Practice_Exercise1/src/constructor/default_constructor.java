package constructor;

public class default_constructor {
	//creating a default constructor  
	default_constructor(){System.out.println("default_constructor is created");}  
	//main method  
	public static void main(String args[]){  
	//calling a default constructor  
		default_constructor b=new default_constructor();  
	}  

}
