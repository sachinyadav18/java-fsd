package constructor;

public class parameterized_constructor {
	  
	    int id;  
	    String name;  
	    //creating a parameterized constructor  
	    parameterized_constructor(int i,String n){  
	    id = i;  
	    name = n;  
	    }  
	    //method to display the values  
	    void display(){System.out.println(id+" "+name);}  
	   
	    public static void main(String args[]){  
	    //creating objects and passing values  
	    	parameterized_constructor s1 = new parameterized_constructor(111,"Karan");  
	    	parameterized_constructor s2 = new parameterized_constructor(222,"Aryan");  
	    //calling method to display the values of object  
	    s1.display();  
	    s2.display();  
	   }  
	}  


