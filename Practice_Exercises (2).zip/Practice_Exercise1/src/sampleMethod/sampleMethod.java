package sampleMethod;

public class sampleMethod {

		  // create a method
		  public int addNumbers(int a, int b) {
		    int sum = a + b;
		    // return value
		    return sum;
		  }

		  public static void main(String[] args) {
		    
		    int num1 = 15;
		    int num2 = 5;

		    // create an object of Main
		    sampleMethod obj = new sampleMethod();
		    // calling method
		    int result = obj.addNumbers(num1, num2);
		    System.out.println("Sum is: " + result);
		  }
		

}
