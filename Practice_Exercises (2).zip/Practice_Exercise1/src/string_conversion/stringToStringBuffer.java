package string_conversion;

public class stringToStringBuffer {
	
		 
	    public static void main(String[] args) {
	 
	       
	        String s1 = "String ";
	 
	        
	        StringBuffer s = new StringBuffer();
	 
	        
	        s.append(s1);
	 
	        
	        String s2 = "to ";
	 
	       
	        s.append(s2);
	 
	        
	        String s3 = "string buffer";
	 
	       
	        s.append( s3);
	 
	        System.out.println(s);
	    }
}

